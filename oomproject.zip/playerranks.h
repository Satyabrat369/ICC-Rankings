#include "pODI.h"
#include "pT20.h"
#include "ptests.h"
#ifndef __playerranks
#define __playerranks
class playerranks:protected pODI,protected pT20,protected ptests
{
    public:
    void displayfactorsplayer(int);
    void others();
    void assignp();
};
#endif