#ifndef __tT20
#define __tT20
#include<map>
using namespace std;
class tT20
{
protected:
    map<string,int> tmrnk2;
    map<string,int> tmrat2;
    map<int,string> rnktm2;
public:
    void assignt2();
    //store name of name and ranks of top teams
    //we can use map similarly
};
#endif