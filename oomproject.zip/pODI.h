#ifndef __pODI
#define __pODI
#include<map>
using namespace std;
class pODI
{
protected:
    map<string,int> nmrnkbt1;
    map<string,int> nmrnkbw1;
    map<string,int> nmrnkar1;

    map<string,int> nmratbt1;
    map<string,int> nmratbw1;
    map<string,int> nmratar1;

    map<int,string> rnknmbt1;
    map<int,string> rnknmbw1;
    map<int,string> rnknmar1;
public:
    void assignp1();
};
#endif