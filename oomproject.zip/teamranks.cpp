#include<iostream>
#include "teamranks.h"
void teamranks::displayfactorsteam()
{
    cout<<"1.who wins the match\n2.no. of matches won\n3.rating of opponents\n";
    cout<<"Ratings=total points earned/number of matches played";
}
void teamranks::assignt()
{
    assignt1();
    assignt2();
    assignt3();
}