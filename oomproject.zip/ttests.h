#ifndef __ttests
#define __ttests
#include<map>
using namespace std;
class ttests
{
protected:
    map<string,int> tmrnk3;
    map<string,int> tmrat3;
    map<int,string> rnktm3;
public:
    void assignt3();
    //store name of name and ranks of top teams
    //we can use map similarly
};
#endif