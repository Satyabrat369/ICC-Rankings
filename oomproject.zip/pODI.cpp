#include "pODI.h"

void pODI::assignp1()
{
    rnknmbt1[1]="Baber Azam";
    nmrnkbt1["Baber Azam"]=1;
    nmratbt1["Baber Azam"]=865;

    rnknmbt1[2]="Virat Kohli";
    nmrnkbt1["Virat Kohli"]=2;
    nmratbt1["Virat Kohli"]=857;

    rnknmbt1[3]="Rohit Sharma";
    nmrnkbt1["Rohit Sharma"]=3;
    nmratbt1["Rohit Sharma"]=825;

    rnknmbt1[4]="Ross Taylor";
    nmrnkbt1["Ross Taylor"]=4;
    nmratbt1["Ross Taylor"]=801;

    rnknmbt1[5]="Aaron Finch";
    nmrnkbt1["Aaron Finch"]=5;
    nmratbt1["Aaron Finch"]=791;

    rnknmbt1[6]="Jonny Bairstow";
    nmrnkbt1["Jonny Bairstow"]=6;
    nmratbt1["Jonny Bairstow"]=785;

    rnknmbt1[7]="Fakhar Zaman";
    nmrnkbt1["Fakhar Zaman"]=7;
    nmratbt1["Fakhar Zaman"]=778;

    rnknmbt1[8]="Francois du Plessis";
    nmrnkbt1["Francois du Plessis"]=8;
    nmratbt1["Francois du Plessis"]=778;

    rnknmbt1[9]="David Warner";
    nmrnkbt1["David Warner"]=9;
    nmratbt1["David Warner"]=773;

    rnknmbt1[10]="Shai Hope";
    nmrnkbt1["Shai Hope"]=10;
    nmratbt1["Shai Hope"]=773;

    rnknmbw1[1]="Trent Boult";
    nmrnkbw1["Trent Boult"]=1;
    nmratbw1["Trent Boult"]=737;

    rnknmbw1[2]="Mehedi Hasan";
    nmrnkbw1["Mehedi Hasan"]=2;
    nmratbw1["Mehedi Hasan"]=713;

    rnknmbw1[3]="Mujeeb Ur Rahman";
    nmrnkbw1["Mujeeb Ur Rahman"]=3;
    nmratbw1["Mujeeb Ur Rahman"]=708;

    rnknmbw1[4]="Matt Henry";
    nmrnkbw1["Matt Henry"]=4;
    nmratbw1["Matt Henry"]=691;

    rnknmbw1[5]="Jasprit Bumrah";
    nmrnkbw1["Jasprit Bumrah"]=5;
    nmratbw1["Jasprit Bumrah"]=690;

    rnknmbw1[6]="Kagiso Rabada";
    nmrnkbw1["Kagiso Rabada"]=6;
    nmratbw1["Kagiso Rabada"]=737;

    rnknmbw1[7]="Chris Woakes";
    nmrnkbw1["Chris Woakes"]=7;
    nmratbw1["Chris Woakes"]=665;

    rnknmbw1[8]="Josh Hazlewood";
    nmrnkbw1["Josh Hazlewood"]=8;
    nmratbw1["Josh Hazlewood"]=660;

    rnknmbw1[9]="Pat Cummins";
    nmrnkbw1["Pat Cummins"]=9;
    nmratbw1["Pat Cummins"]=646;

    rnknmbw1[10]="Mustafizur Rahman";
    nmrnkbw1["Mustafizur Rahman"]=10;
    nmratbw1["Mustafizur Rahman"]=645;

    rnknmar1[1]="Shakib Al Hasan";
    nmrnkar1["Shakib Al Hasan"]=1;
    nmratar1["Shakib Al Hasan"]=387;

    rnknmar1[2]="Ben Stokes";
    nmrnkar1["Ben Stokes"]=2;
    nmratar1["Ben Stokes"]=295;

    rnknmar1[3]="Mohammad Nabi";
    nmrnkar1["Mohammad Nabi"]=3;
    nmratar1["Mohammad Nabi"]=294;

    rnknmar1[4]="Chris Woakes";
    nmrnkar1["Chris Woakes"]=4;
    nmratar1["Chris Woakes"]=273;

    rnknmar1[5]="Rashid Khan";
    nmrnkar1["Rashid Khan"]=5;
    nmratar1["Rashid Khan"]=270;

    rnknmar1[6]="Mitchell Santner";
    nmrnkar1["Mitchell Santner"]=6;
    nmratar1["Mitchell Santner"]=268;

    rnknmar1[7]="Imad Wasim";
    nmrnkar1["Imad Wasim"]=7;
    nmratar1["Imad Wasim"]=263;

    rnknmar1[8]="Colin de Grandhomme";
    nmrnkar1["Colin de Grandhomme"]=8;
    nmratar1["Colin de Grandhomme"]=257;

    rnknmar1[9]="Ravindra Jadeja";
    nmrnkar1["Ravindra Jadeja"]=9;
    nmratar1["Ravindra Jadeja"]=245;

    rnknmar1[10]="Sean Williams";
    nmrnkar1["Sean Williams"]=10;
    nmratar1["Sean Williams"]=238;
}