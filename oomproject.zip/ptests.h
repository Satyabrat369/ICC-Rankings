#ifndef __ptests
#define __ptests
using namespace std;
#include<map>
class ptests
{
protected:
    map<string,int> nmrnkbt3;
    map<string,int> nmratbt3;
    map<int,string> rnknmbt3;

    map<string,int> nmrnkbw3;
    map<string,int> nmratbw3;
    map<int,string> rnknmbw3;

    map<string,int> nmrnkar3;
    map<string,int> nmratar3;
    map<int,string> rnknmar3;

public:
    void assignp3();
    //store name and ranks of top players in batsman/bowler/allround
    //we can use map to connect ranks,ratings to names 
};
#endif