#include<iostream>
#include "display.h"

void display::displayteam(int x,int y,string name,int rank)
{
    //if(y==1)for ODI
    //if(y==2)for T20
    //if(y==3)for tests
    if(x==1)
    {
        if(y==1)
            cout<<rnktm1[rank];
        if(y==2)
            cout<<rnktm2[rank];
        if(y==3)
            cout<<rnktm3[rank];
        //display team
    }
    if(x==2)
    {
        if(y==1)
        {
            if(tmrnk1.count(name)==0)
            {
                cout<<"Not found in top 10\n";
                return;
            }
            cout<<tmrnk1[name];
        }
        if(y==2)
        {
            if(tmrnk2.count(name)==0)
            {
                cout<<"Not found in top 10\n";
                return;
            }
            cout<<tmrnk2[name];
        }
        if(y==3)
        {
            if(tmrnk3.count(name)==0)
            {
                cout<<"Not found in top 10\n";
                return;
            }
            cout<<tmrnk3[name];
        }
        //display rank
    }
    if(x==3)
    {
        if(y==1)
        {
            if(tmrnk1.count(name)==0)
            {
                cout<<"Not found in top 10\n";
                return;
            }
            cout<<tmrat1[name];
        }
        if(y==2)
        {
            if(tmrnk2.count(name)==0)
            {
                cout<<"Not found in top 10\n";
                return;
            }
            cout<<tmrat2[name];
        }
        if(y==3)
        {
            if(tmrnk3.count(name)==0)
            {
                cout<<"Not found in top 10\n";
                return;
            }
            cout<<tmrat3[name];
        }
        //display rating
    }
}
void display::displayplayer(int player,int x,int y,string name,int rank)
{
    if(name!="")
    {
        if(nmrnkbt1.count(name)==0 && nmrnkbt2.count(name)==0 && 
        nmrnkbt3.count(name)==0 && nmrnkbw1.count(name)==0 && nmrnkbw2.count(name)==0 
        && nmrnkbw3.count(name)==0 && nmrnkar1.count(name)==0 && nmrnkar2.count(name)==0 
        && nmrnkar3.count(name)==0)
        {
            cout<<"Not found in top 10\n";
            return;
        }
    }
    if(x==5)
    {
        others();
        return;
    }
    if(x==4)
    {
        displayfactorsplayer(player);
        return;
    }
    //if(y==1)for ODI
    //if(y==2)for T20
    //if(y==3)for tests
    if(player==1)
    {
        //display for batsman
        if(x==1)
        {
            if(y==1)
                cout<<rnknmbt1[rank];
            if(y==2)
                cout<<rnknmbt2[rank];
            if(y==3)
                cout<<rnknmbt3[rank];
        }
        //display name 
        if(x==2)
        {
            if(y==1)
            {
                if(nmrnkbt1.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmrnkbt1[name];
            }
            if(y==2)
            {
                if(nmrnkbt2.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmrnkbt2[name];
            }
            if(y==3)
            {
                if(nmrnkbt3.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmrnkbt3[name];
            }
        }
        //display rank 
        if(x==3)
        {
            if(y==1)
            {
                if(nmratbt1.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmratbt1[name];
            }
            if(y==2)
            {
                if(nmratbt2.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmratbt2[name];
            }
            if(y==3)
            {
                if(nmratbt3.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmratbt3[name];
            }
        }
        //display ratings 
    }
    if(player==2)
    {
        //display for bowlers
        if(x==1)
        {
            if(y==1)
                cout<<rnknmbw1[rank];
            if(y==2)
                cout<<rnknmbw2[rank];
            if(y==3)
                cout<<rnknmbw3[rank];
        }
        //display name 
        if(x==2)
        {
            if(y==1)
            {
                if(nmrnkbw1.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmrnkbw1[name];
            }
            if(y==2)
            {
                if(nmrnkbw2.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmrnkbw2[name];
            }
            if(y==3)
            {
                if(nmrnkbw3.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmrnkbw3[name];
            }
        }
        //display rank 
        if(x==3)
        {
            if(y==1)
            {
                if(nmratbw1.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmratbw1[name];
            }
            if(y==2)
            {
                if(nmratbw2.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmratbw2[name];
            }
            if(y==3)
            {
                if(nmratbw3.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmratbw3[name];
            }
        }
        //display ratings
    }
    if(player==3)
    {
        //display for allrounder
        if(x==1)
        {
            if(y==1)
                cout<<rnknmar1[rank];
            if(y==2)
                cout<<rnknmar2[rank];
            if(y==3)
                cout<<rnknmar3[rank];
        }
        //display name 
        if(x==2)
        {
            if(y==1)
            {
                if(nmrnkar1.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmrnkar1[name];
            }
            if(y==2)
            {
                if(nmrnkar2.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmrnkar2[name];
            }
            if(y==3)
            {
                if(nmrnkar3.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmrnkar3[name];
            }
        }
        //display rank 
        if(x==3)
        {
            if(y==1)
            {
                if(nmratar1.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmratar1[name];
            }
            if(y==2)
            {
                if(nmratar2.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmratar2[name];
            }
            if(y==3)
            {
                if(nmratar3.count(name)==0)
                {
                    cout<<"Not found in top 10\n";
                    return;
                }
                cout<<nmratar3[name];
            }
        }
        //display ratings
    }
}