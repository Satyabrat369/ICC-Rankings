#include "pT20.h"

void pT20::assignp2()
{
    rnknmbt2[1]="David Malan";
    nmrnkbt2["David Malan"]=1;
    nmratbt2["David Malan"]=888;

    rnknmbt2[2]="Aaron Finch";
    nmrnkbt2["Aaron Finch"]=2;
    nmratbt2["Aaron Finch"]=830;

    rnknmbt2[3]="Babar Azam";
    nmrnkbt2["Babar Azam"]=3;
    nmratbt2["Babar Azam"]=828;

    rnknmbt2[4]="Devon Conway";
    nmrnkbt2["Devon Conway"]=4;
    nmratbt2["Devon Conway"]=774;

    rnknmbt2[5]="Virat Kohli";
    nmrnkbt2["Virat Kohli"]=5;
    nmratbt2["Virat Kohli"]=762;

    rnknmbt2[6]="Russie van ser Dussen";
    nmrnkbt2["Russie van ser Dussen"]=6;
    nmratbt2["Russie van ser Dussen"]=747;

    rnknmbt2[7]="Lokesh Rahul";
    nmrnkbt2["Lokesh Rahul"]=7;
    nmratbt2["Lokesh Rahul"]=743;

    rnknmbt2[8]="Glenn Maxwell";
    nmrnkbt2["Glenn Maxwell"]=8;
    nmratbt2["Glenn Maxwell"]=694;

    rnknmbt2[9]="Martin Guptill";
    nmrnkbt2["Martin Guptill"]=9;
    nmratbt2["Martin Guptill"]=688;

    rnknmbt2[10]="Evin Lewis";
    nmrnkbt2["Evin Lewis"]=10;
    nmratbt2["Evin Lewis"]=676;

    rnknmbw2[1]="Tabraiz Shamsi";
    nmrnkbw2["Tabraiz Shamsi"]=1;
    nmratbw2["Tabraiz Shamsi"]=750;

    rnknmbw2[2]="Rashid Khan";
    nmrnkbw2["Rashid Khan"]=2;
    nmratbw2["Rashid Khan"]=719;

    rnknmbw2[3]="Ashton Agar";
    nmrnkbw2["Ashton Agar"]=3;
    nmratbw2["Ashton Agar"]=702;

    rnknmbw2[4]="Adil Rashid";
    nmrnkbw2["Adil Rashid"]=4;
    nmratbw2["Adil Rashid"]=695;

    rnknmbw2[5]="Wanindu De Silva";
    nmrnkbw2["Wanindu De Silva"]=5;
    nmratbw2["Wanindu De Silva"]=693;

    rnknmbw2[6]="Mujeeb Ur Rahman";
    nmrnkbw2["Mujeeb Ur Rahman"]=6;
    nmratbw2["Mujeeb Ur Rahman"]=687;

    rnknmbw2[7]="Tim Southee";
    nmrnkbw2["Tim Southee"]=7;
    nmratbw2["Tim Southee"]=669;

    rnknmbw2[8]="Adam Zampa";
    nmrnkbw2["Adam Zampa"]=8;
    nmratbw2["Adam Zampa"]=663;

    rnknmbw2[9]="Ish Sodhi";
    nmrnkbw2["Ish Sodhi"]=9;
    nmratbw2["Ish Sodhi"]=640;

    rnknmbw2[10]="Mitchell Santner";
    nmrnkbw2["Mitchell Santner"]=10;
    nmratbw2["Mitchell Santner"]=616;

    rnknmar2[1]="Mohammad Nabi";
    nmrnkar2["Mohammad Nabi"]=1;
    nmratar2["Mohammad Nabi"]=285;

    rnknmar2[2]="Shakib Al Hasan";
    nmrnkar2["Shakib Al Hasan"]=2;
    nmratar2["Shakib Al Hasan"]=238;

    rnknmar2[3]="Glenn Maxwell";
    nmrnkar2["Glenn Maxwell"]=3;
    nmratar2["Glenn Maxwell"]=226;

    rnknmar2[4]="Richard Berrington";
    nmrnkar2["Richard Berrington"]=4;
    nmratar2["Richard Berrington"]=194;

    rnknmar2[5]="Gareth Delany";
    nmrnkar2["Gareth Delany"]=5;
    nmratar2["Gareth Delany"]=170;

    rnknmar2[6]="Khawar Ali";
    nmrnkar2["Khawar Ali"]=6;
    nmratar2["Khawar Ali"]=159;

    rnknmar2[7]="Sean Williams";
    nmrnkar2["Sean Williams"]=7;
    nmratar2["Sean Williams"]=158;

    rnknmar2[8]="Collins Obuya";
    nmrnkar2["Collins Obuya"]=8;
    nmratar2["Collins Obuya"]=153;

    rnknmar2[9]="Rohan Mustafa";
    nmrnkar2["Rohan Mustafa"]=9;
    nmratar2["Rohan Mustafa"]=152;

    rnknmar2[10]="Zeeshan Maqsood";
    nmrnkar2["Zeeshan Maqsood"]=10;
    nmratar2["Zeeshan Maqsood"]=135;
}