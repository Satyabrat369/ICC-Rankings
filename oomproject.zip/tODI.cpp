#include "tODI.h"

void tODI::assignt1()
{
    rnktm1[1]="New Zealand";
    tmrnk1["New Zealand"]=1;
    tmrat1["New Zealand"]=121;

    rnktm1[2]="Australia";
    tmrnk1["Australia"]=2;
    tmrat1["Australia"]=118;
    
    rnktm1[3]="England";
    tmrnk1["England"]=3;
    tmrat1["England"]=116;
    
    rnktm1[4]="India";
    tmrnk1["India"]=4;
    tmrat1["India"]=115;
    
    rnktm1[5]="South Africa";
    tmrnk1["South Africa"]=5;
    tmrat1["South Africa"]=107;
    
    rnktm1[6]="Pakistan";
    tmrnk1["Pakistan"]=6;
    tmrat1["Pakistan"]=97;
    
    rnktm1[7]="Bangladesh";
    tmrnk1["Bangladesh"]=7;
    tmrat1["Bangladesh"]=90;
    
    rnktm1[8]="West Indies";
    tmrnk1["West Indies"]=8;
    tmrat1["West Indies"]=82;
    
    rnktm1[9]="Sri Lanka";
    tmrnk1["Sri Lanka"]=9;
    tmrat1["Sri Lanka"]=77;
    
    rnktm1[10]="Afghanistan";
    tmrnk1["Afghanistan"]=10;
    tmrat1["New Zealand"]=62;
}