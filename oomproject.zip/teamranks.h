#include "tODI.h"
#include "tT20.h"
#include "ttests.h"
#ifndef __teamranks
#define __teamranks
class teamranks:protected tODI,protected tT20,protected ttests
{
    public:
    void displayfactorsteam();
    void assignt();
};
#endif
