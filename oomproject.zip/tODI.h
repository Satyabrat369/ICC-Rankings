#ifndef __tODI
#define __tODI
#include<map>
using namespace std;
class tODI                    //team->rank//rank->team//team->rating
{
protected:
    map<string,int> tmrnk1;
    map<string,int> tmrat1;
    map<int,string> rnktm1;
public:
    void assignt1();
    //store name of name and ranks of top teams
    //we can use map similarly
};
#endif