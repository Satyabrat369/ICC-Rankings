#include "ptests.h"

void ptests::assignp3()
{
    rnknmbt3[1]="Kane Williamson";
    nmrnkbt3["Kane Williamson"]=1;
    nmratbt3["Kane Williamson"]=901;

    rnknmbt3[2]="Steve Smith";
    nmrnkbt3["Steve Smith"]=2;
    nmratbt3["Steve Smith"]=891;

    rnknmbt3[3]="Marnus Labuschagne";
    nmrnkbt3["Marnus Labuschagne"]=3;
    nmratbt3["Marnus Labuschagne"]=878;

    rnknmbt3[4]="Virat Kohli";
    nmrnkbt3["Virat Kohli"]=4;
    nmratbt3["Virat Kohli"]=812;

    rnknmbt3[5]="Joe Root";
    nmrnkbt3["Joe Root"]=5;
    nmratbt3["Joe Root"]=797;

    rnknmbt3[6]="Rohit Sharma";
    nmrnkbt3["Rohit Sharma"]=6;
    nmratbt3["Rohit Sharma"]=759;

    rnknmbt3[7]="Rishabh Pant";
    nmrnkbt3["Rishabh Pant"]=7;
    nmratbt3["Rishabh Pant"]=752;

    rnknmbt3[8]="David Warner";
    nmrnkbt3["David Warner"]=8;
    nmratbt3["David Warner"]=724;

    rnknmbt3[9]="Quinton de Kock";
    nmrnkbt3["Quinton de Kock"]=9;
    nmratbt3["Quinton de Kock"]=717;

    rnknmbt3[10]="Henry Nicholls";
    nmrnkbt3["Henry Nicholls"]=10;
    nmratbt3["Henry Nicholls"]=714;

    rnknmbw3[1]="Pat Cummins";
    nmrnkbw3["Pat Cummins"]=1;
    nmratbw3["Pat Cummins"]=908;

    rnknmbw3[2]="Ravichandran Ashwin";
    nmrnkbw3["Ravichandran Ashwin"]=2;
    nmratbw3["Ravichandran Ashwin"]=865;

    rnknmbw3[3]="Tim Southee";
    nmrnkbw3["Tim Southee"]=3;
    nmratbw3["Tim Southee"]=824;

    rnknmbw3[4]="Josh Hazlewood";
    nmrnkbw3["Josh Hazlewood"]=4;
    nmratbw3["Josh Hazlewood"]=816;

    rnknmbw3[5]="Neil Wagner";
    nmrnkbw3["Neil Wagner"]=5;
    nmratbw3["Neil Wagner"]=810;

    rnknmbw3[6]="Kagiso Rabada";
    nmrnkbw3["Kagiso Rabada"]=6;
    nmratbw3["Kagiso Rabada"]=798;

    rnknmbw3[7]="Stuart Broad";
    nmrnkbw3["Stuart Broad"]=7;
    nmratbw3["Stuart Broad"]=793;

    rnknmbw3[8]="James Anderson";
    nmrnkbw3["James Anderson"]=8;
    nmratbw3["James Anderson"]=783;

    rnknmbw3[9]="Mitchell Starc";
    nmrnkbw3["Mitchell Starc"]=9;
    nmratbw3["Mitchell Starc"]=744;

    rnknmbw3[10]="Jason Holder";
    nmrnkbw3["Jason Holder"]=10;
    nmratbw3["Jason Holder"]=740;

    rnknmar3[1]="Jason Holder";
    nmrnkar3["Jason Holder"]=1;
    nmratar3["Jason Holder"]=384;

    rnknmar3[2]="Ben Stokes";
    nmrnkar3["Ben Stokes"]=2;
    nmratar3["Ben Stokes"]=377;

    rnknmar3[3]="Ravindra Jadeja";
    nmrnkar3["Ravindra Jadeja"]=3;
    nmratar3["Ravindra Jadeja"]=377;

    rnknmar3[4]="Ravichandran Ashwin";
    nmrnkar3["Ravichandran Ashwin"]=4;
    nmratar3["Ravichandran Ashwin"]=358;

    rnknmar3[5]="Shakib Al Hasan";
    nmrnkar3["Shakib Al Hasan"]=5;
    nmratar3["Shakib Al Hasan"]=338;

    rnknmar3[6]="Kyle Jamieson";
    nmrnkar3["Kyle Jamieson"]=6;
    nmratar3["Kyle Jamieson"]=311;

    rnknmar3[7]="Mitchell Starc";
    nmrnkar3["Mitchell Starc"]=7;
    nmratar3["Mitchell Starc"]=275;

    rnknmar3[8]="Pat Cummins";
    nmrnkar3["Pat Cummins"]=8;
    nmratar3["Pat Cummins"]=249;

    rnknmar3[9]="Colin de Grandhomme";
    nmrnkar3["Colin de Grandhomme"]=9;
    nmratar3["Colin de Grandhomme"]=232;

    rnknmar3[10]="Chris Woakes";
    nmrnkar3["Chris Woakes"]=10;
    nmratar3["Chris Woakes"]=229;
}