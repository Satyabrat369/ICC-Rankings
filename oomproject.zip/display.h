#include "playerranks.h"
#include "teamranks.h"
#ifndef __display
#define __display
class display:public playerranks,public teamranks
{
    public:
    void displayteam(int,int,string,int);
    void displayplayer(int,int,int,string,int);
};
#endif