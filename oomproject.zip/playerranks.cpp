#include<iostream>
#include "playerranks.h"

void playerranks::displayfactorsplayer(int x)
{
    if(x==1)
    cout<<"1.Runs scored\n2.Rating of opposition bowlers\n3.Score in low scoring games results in higher rating than in high score game\n4.not out innings\n5.result of match\n";
    if(x==2)
        cout<<"1.wicket taken and run concede\n2.ratings of batsman dismissed\n3.Runs made by oppostie batsman differs from low score and hig score matches\n4.number of overs bowled\n5.result of match\n";
    if(x==3)
        cout<<"rating points=[batting point x bowling point]/1000\n";
}
void playerranks::others()
{
        cout<<"player retires,removed from ranking list\nnew rating at end of match\nnew ranking at the end of each series of ODI and T20\nperson should appear in match for(12-15 for test and 9-12 for ODi an T20) for qualifying to be included in ranking lists\n";
}
void playerranks::assignp()
{
    assignp1();
    assignp2();
    assignp3();
}