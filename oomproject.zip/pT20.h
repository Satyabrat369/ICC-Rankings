#ifndef __pT20
#define __pT20
#include<map>
using namespace std;
class pT20
{
protected:
    map<string,int> nmrnkbt2;
    map<string,int> nmratbt2;
    map<int,string> rnknmbt2;

    map<string,int> nmrnkbw2;
    map<string,int> nmratbw2;
    map<int,string> rnknmbw2;

    map<string,int> nmrnkar2;
    map<string,int> nmratar2;
    map<int,string> rnknmar2;

public:
    void assignp2();
    //store name and ranks of top players in batsman/bowler/allround
    //we can use map to connect ranks,ratings to names 
};
#endif