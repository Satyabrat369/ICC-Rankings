#include "ttests.h"
void ttests::assignt3()
{
    rnktm3[1]="New Zealand";
    tmrnk3["New Zealand"]=1;
    tmrat3["New Zealand"]=126;

    rnktm3[2]="India";
    tmrnk3["India"]=2;
    tmrat3["India"]=119;
    
    rnktm3[3]="Australia";
    tmrnk3["Australia"]=3;
    tmrat3["Australia"]=108;
    
    rnktm3[4]="England";
    tmrnk3["England"]=4;
    tmrat3["England"]=107;
    
    rnktm3[5]="Pakistan";
    tmrnk3["Pakistan"]=5;
    tmrat3["Pakistan"]=94;
    
    rnktm3[6]="South Africa";
    tmrnk3["South Africa"]=6;
    tmrat3["South Africa"]=88;
    
    rnktm3[7]="West Indies";
    tmrnk3["West Indies"]=7;
    tmrat3["West Indies"]=78;
    
    rnktm3[8]="Sri Lanka";
    tmrnk3["Sri Lanka"]=8;
    tmrat3["Sri Lanka"]=78;
    
    rnktm3[9]="Bangladesh";
    tmrnk3["Bangladesh"]=9;
    tmrat3["Bangladesh"]=46;
    
    rnktm3[10]="Zimbabwe";
    tmrnk3["Zimbabwe"]=10;
    tmrat3["Zimbabwe"]=35;
}