#include "tT20.h"

void tT20::assignt2()
{
    rnktm2[1]="England";
    tmrnk2["England"]=1;
    tmrat2["England"]=278;
    rnktm2[2]="India";
    tmrnk2["India"]=2;
    tmrat2["India"]=272;
    rnktm2[3]="New Zealand";
    tmrnk2["New Zealand"]=3;
    tmrat2["New Zealand"]=263;
    rnktm2[4]="Pakistan";
    tmrnk2["Pakistan"]=4;
    tmrat2["Pakistan"]=261;
    rnktm2[5]="Australia";
    tmrnk2["Australia"]=5;
    tmrat2["Australia"]=258;
    rnktm2[6]="South Africa";
    tmrnk2["South Africa"]=6;
    tmrat2["South Africa"]=243;
    rnktm2[7]="Afghanistan";
    tmrnk2["Afghanistan"]=7;
    tmrat2["Afghanistan"]=236;
    rnktm2[8]="West Indies";
    tmrnk2["West Indies"]=8;
    tmrat2["West Indies"]=226;
    rnktm2[9]="Sri Lanka";
    tmrnk2["Sri Lanka"]=9;
    tmrat2["Sri Lanka"]=225;
    rnktm2[10]="Banglasdesh";
    tmrnk2["Bangladesh"]=10;
    tmrat2["Bangladesh"]=278;
}