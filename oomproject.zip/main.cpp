#include "display.h"
#include<iostream>
int main()
{
    cout<<"This project contains info only about the top 10 players,ranks,ratings\n";
    int count=1;
    display d;
    d.assignp();
    d.assignt();
    while(count==1)
    {
        int a;
        cout<<"Enter 1 for team.2 for players search:\n";
        cin>>a;
        if(a!=1 && a!=2)
        {
            cout<<"Invalid input\n";
            goto end;
        }
        if(a==1)
        {
            string name="";
            int rank=-1;
            int x,f;
            cout<<"Enter\n1.ODI\n2.T20\n3.tests\n";
            cin>>f;
            if(f<1 || f>3)
            {
                cout<<"Invalid input\n";
                goto end;
            }
            cout<<"Enter\n1.display team for given rank\n2.rank of a team\n3.rating of a team\n4.display factors on which ratings depend:\n";
            cin>>x;
            if(x==1)
            {
                cout<<"Enter rank:\n";
                cin>>rank;
                if(rank<1 || rank>10)
                {
                    cout<<"Rank not from 1 to 10\n";
                    goto end;
                }
            }
            if(x==2 || x==3)
            {
                cout<<"Enter name of team:\n";
                cin>>name;
            }
            if(x==1 || x==2 || x==3)
                d.displayteam(x,f,name,rank); //we use constant for value which we dont need
            else if(x==4)
                d.displayfactorsteam();
            else
            {
                cout<<"Invalid input\n";
                goto end;
            }
        }
        if(a==2)
        {
            int rank=0;
            string name="";
            int x,y,f;
            cout<<"Enter\n1.ODI\n2.T20\n3.tests:\n";
            cin>>f;
            if(f<1 && f>3)
            {
                cout<<"Invalid Input\n";
                goto end;
            }
            cout<<"Enter\n1.batsman\n2.bowler\n3.allrounder:\n";
            cin>>x;
            if(x<1 || x>3)
            {
                cout<<"Invalid input\n";
                goto end;
            }
            cout<<"Enter\n1.name for a rank\n2.rank for a name\n3.rating for name\n4.factors on which rating depends\n5.others:\n";
            cin>>y;
            if(y==1)
            {
                cout<<"Enter rank:\n";
                cin>>rank;
                if(rank<1 || rank>10)
                {
                    cout<<"Rank not from 1 to 10\n";
                    goto end;
                }
            }
            if(y==2 || y==3)
            {
                cout<<"Enter name of player:\n";
                cin>>name;
            }
            if(y<1 || y>5)
            {
                cout<<"Invalid input\n";
                goto end;
            }
            d.displayplayer(x,y,f,name,rank);//we use constants for value which we dont need
        }
        cout<<"\n";
        end:
        cout<<"Do you want to see again?\n1.Yes\n2.No:\n";
        cin>>count;
    }
    return 0;
}